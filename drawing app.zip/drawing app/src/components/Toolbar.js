import React from 'react';

const Toolbar = () => {
    return (
        <div className="toolbar">
            {/* Add your buttons and inputs for tools here */}
            <button>Brush</button>
            <button>Eraser</button>
            <button>Rectangle</button>
            <button>Circle</button>
            <input type="color" />
            <input type="range" min="1" max="10" />
        </div>
    );
};

export default Toolbar;
